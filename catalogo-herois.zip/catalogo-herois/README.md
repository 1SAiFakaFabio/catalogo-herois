# Catálogo de Heróis

Projeto em Node.js + Express que apresenta as empresas Marvel e DC e seus personagens, com respostas em HTML via `res.send()`.

## Como executar

```bash
npm install
npm start
```

Acesse `http://localhost:3030`.

## Rotas

| Rota | Descrição |
| --- | --- |
| `/` | Página inicial com título, boas-vindas, links das empresas, `<hr>` e links de personagens |
| `/marvel` | Página da Marvel com descrição, lista de personagens e link para o início |
| `/dc` | Página da DC com descrição, lista de personagens e link para o início |
| `/personagem/:empresa/:nome` | Exibe empresa e nome recebidos via `req.params` |

Exemplos:

- http://localhost:3030/personagem/marvel/Thor
- http://localhost:3030/personagem/dc/Batman
