const express = require('express');
const app = express();
const PORT = 3030;

// Dados das empresas e seus personagens
const empresas = {
  marvel: {
    nome: 'Marvel',
    descricao:
      'A Marvel Comics é uma das maiores editoras de quadrinhos do mundo, criadora de heróis como Homem-Aranha, Thor e Homem de Ferro, que formam o universo dos Vingadores.',
    personagens: ['Thor', 'Homem-Aranha', 'Homem de Ferro', 'Capitao America'],
  },
  dc: {
    nome: 'DC',
    descricao:
      'A DC Comics é uma das mais tradicionais editoras de quadrinhos, criadora de heróis como Batman, Superman e Mulher-Maravilha, que formam a Liga da Justiça.',
    personagens: ['Batman', 'Superman', 'Mulher-Maravilha', 'Flash'],
  },
};

// Evita que o conteúdo da URL seja interpretado como HTML
function escapar(texto) {
  return String(texto)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

// Monta o link de um personagem
function linkPersonagem(chaveEmpresa, nome) {
  return `<a href="/personagem/${chaveEmpresa}/${encodeURIComponent(nome)}">${escapar(nome)}</a>`;
}

// Estrutura base das páginas
function pagina(titulo, corpo) {
  return `<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${escapar(titulo)}</title>
</head>
<body>
${corpo}
</body>
</html>`;
}

// 1. Página inicial
app.get('/', (req, res) => {
  res.send(
    pagina(
      'Catálogo de Heróis',
      `  <h1>Catálogo de Heróis</h1>
  <p>Bem-vindo ao Catálogo de Heróis! Explore as empresas e conheça seus personagens.</p>
  <h2>Empresas</h2>
  <ul>
    <li><a href="/marvel">Marvel</a></li>
    <li><a href="/dc">DC</a></li>
  </ul>
  <hr>
  <h2>Personagens</h2>
  <ul>
    <li>${linkPersonagem('marvel', 'Thor')}</li>
    <li>${linkPersonagem('marvel', 'Homem-Aranha')}</li>
    <li>${linkPersonagem('dc', 'Batman')}</li>
    <li>${linkPersonagem('dc', 'Superman')}</li>
  </ul>`
    )
  );
});

// 2. Rotas das empresas
function rotaEmpresa(chave) {
  return (req, res) => {
    const empresa = empresas[chave];
    const itens = empresa.personagens
      .map((p) => `    <li>${linkPersonagem(chave, p)}</li>`)
      .join('\n');

    res.send(
      pagina(
        empresa.nome,
        `  <h1>${empresa.nome}</h1>
  <p>${empresa.descricao}</p>
  <h2>Personagens</h2>
  <ul>
${itens}
  </ul>
  <p><a href="/">Voltar para a página inicial</a></p>`
      )
    );
  };
}

app.get('/marvel', rotaEmpresa('marvel'));
app.get('/dc', rotaEmpresa('dc'));

// 3. Rota com dois parâmetros obrigatórios
app.get('/personagem/:empresa/:nome', (req, res) => {
  const { empresa, nome } = req.params;

  res.send(
    pagina(
      `Personagem: ${nome}`,
      `  <h1>Personagem: ${escapar(nome)}</h1>
  <p><strong>Empresa:</strong> ${escapar(empresa)}</p>
  <p><strong>Nome:</strong> ${escapar(nome)}</p>
  <p><a href="/">Voltar para a página inicial</a></p>`
    )
  );
});

app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});
